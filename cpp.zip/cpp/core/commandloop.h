#ifndef CORE_COMMANDLOOP_H_
#define CORE_COMMANDLOOP_H_

#include "../core/global.h"

namespace CommandLoop {
  std::string processSingleCommandLine(const std::string& s);
}

#endif // CORE_COMMANDLOOP_H_
