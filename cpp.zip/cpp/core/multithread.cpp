#include "../core/multithread.h"

/* This file is to ensure multithread.h compiles on its own. */
