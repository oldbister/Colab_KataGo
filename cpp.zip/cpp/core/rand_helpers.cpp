#include "../core/rand_helpers.h"

/* This file is to ensure rand_helpers.h compiles on its own. */
