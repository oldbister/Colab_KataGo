#include "../core/test.h"

/* This file is to ensure test.h compiles on its own. */
