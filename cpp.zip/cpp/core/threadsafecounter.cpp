#include "../core/threadsafecounter.h"

/* This file is to ensure threadsafecounter.h compiles on its own. */
