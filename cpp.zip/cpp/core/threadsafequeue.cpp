#include "../core/threadsafequeue.h"

/* This file is to ensure threadsafequeue.h compiles on its own. */
