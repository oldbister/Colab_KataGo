/*
 * threadsafecounter.h
 * Author: davidwu
 */

#ifndef CORE_THREADTEST_H_
#define CORE_THREADTEST_H_

namespace ThreadTest {
  void runTests();
}

#endif // CORE_THREADTEST_H_
