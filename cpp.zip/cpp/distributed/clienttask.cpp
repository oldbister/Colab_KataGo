#include "../distributed/client.h"

Client::Task::Task()
  :taskId(),
   taskGroup(),
   runId(),
   modelNameBlack(),
   modelNameWhite(),
   config()
{}
