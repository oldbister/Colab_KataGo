These are small and weak neural net models for testing only.

See:
https://github.com/lightvector/KataGo/releases
or
https://d3dndmfyhecmj0.cloudfront.net/

for the actual latest neural nets.

